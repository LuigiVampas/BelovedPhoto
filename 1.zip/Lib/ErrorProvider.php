<?php

class ErrorProvider {
	public static function showError($__error, $__error_reason, $__error_description){
		switch ($__error){
			case 'access_denied':
				
				break;
		}
	}
}
